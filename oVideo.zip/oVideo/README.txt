':' Commands:
:s or :save - create a save at current time (file saves if you close player)
:play / :pause - play / pause video
:#### or :##:## or :### or :#:## or :## or :# - All related to setting the time in the video
:setfile / :sf / :open - Opens file explorer to select a file
:playlist / :openfolder - Opens file explorer to select a folder
:cyclesub - cycles through subtitle tracks
:cycleaudio - cycles through audio tracks

